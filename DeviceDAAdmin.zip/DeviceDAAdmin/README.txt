CA PC APP: DeviceDAAdmin.html
	this sample app displays devices type, polled item count, contact status, poll status along with the last poll date of availability metric family in a table view:
	- for all devices (within the query limit) in the given group context and across the given timerange
	- single or multiple table rows (use CTRL key) can be selected by click, or by buttons "select all" / "select none"
	- following actions can be triggered on the selected devices via button
		- change polling status (ON > OFF and OFF > ON)
		- rediscover
		- update all metric families
	- the action type will be displayed in the action column
	- the table does not refresh automatically
	
	The app  
	- uses CA PM OpenAPI to query availability timestamp
	- uses DA REST calls to retrieve other parameters like device type, contact and poll status 
	- uses DataTables javascript object, see https://datatables.net/examples/basic_init/zero_configuration.html 
	- has to live in CA PC app or browser view (running in a browser directly will cause problem due to cross-site scripting)
	- the app uses CA PC redirector URL that opens the device context page in new browser tab (new 3.1 functionality)
	
	Prerequisites:
	- CA PM 3.1
	
	CA PC App View parameters:
	URL: /pc/apps/user/DeviceDAAdmin/DeviceDAAdmin.html?id={ItemIdDA}&startTime={TimeStartUTC}&endTime={TimeEndUTC}&userrole={UserRoleName}&limit=100
	Height: 600
	
	last update:
	v1.0	May 15, 2017	Lutz Holzbecher, CA

Installation
	1. store DeviceDAAdmin.zip on your workstation
	2. under CA PC Administration -> App Deployment, select the zip archive and install it.
	3. in dashboard editor select two column layout and create an App View (under External Links) and select "Device DA Admin" in the drop down. Save your work.

===================================================================================

License (refer to license.txt in folder for 3rd party license details)

Copyright (c) 2017 CA Technologies
 
The MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 
The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

===================================================================================